package tw.gov.npa.il.action;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.log4j.Logger;

public class IL10A01Q01 extends ActionSupport {
  private static final Logger logger = Logger.getLogger(IL10A01Q01.class);
  
  public String toIL10A01Q01() throws Exception {
    return "success";
  }
}


/* Location:              D:\Qian\IL 居留系統\20200529取得最新程式\IL2\WEB-INF\classes\!\tw\gov\npa\il\action\IL10A01Q01.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */