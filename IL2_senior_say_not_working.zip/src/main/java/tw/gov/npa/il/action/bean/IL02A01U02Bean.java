package tw.gov.npa.il.action.bean;

public class IL02A01U02Bean {
  private int id;
  
  private int ilArcid;
  
  private String ilPspt;
  
  private String ilEnm;
  
  private String ilNtcd;
  
  private String ilBthdt;
  
  private String ilNTNM;
  
  public int getId() {
    return this.id;
  }
  
  public void setId(int id) {
    this.id = id;
  }
  
  public int getIlArcid() {
    return this.ilArcid;
  }
  
  public void setIlArcid(int ilArcid) {
    this.ilArcid = ilArcid;
  }
  
  public String getIlPspt() {
    return this.ilPspt;
  }
  
  public void setIlPspt(String ilPspt) {
    this.ilPspt = ilPspt;
  }
  
  public String getIlEnm() {
    return this.ilEnm;
  }
  
  public void setIlEnm(String ilEnm) {
    this.ilEnm = ilEnm;
  }
  
  public String getIlNtcd() {
    return this.ilNtcd;
  }
  
  public void setIlNtcd(String ilNtcd) {
    this.ilNtcd = ilNtcd;
  }
  
  public String getIlBthdt() {
    return this.ilBthdt;
  }
  
  public void setIlBthdt(String ilBthdt) {
    this.ilBthdt = ilBthdt;
  }
  
  public String getIlNTNM() {
    return this.ilNTNM;
  }
  
  public void setIlNTNM(String ilNTNM) {
    this.ilNTNM = ilNTNM;
  }
}


/* Location:              D:\Qian\IL 居留系統\20200529取得最新程式\IL2\WEB-INF\classes\!\tw\gov\npa\il\action\bean\IL02A01U02Bean.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */