package tw.gov.npa.il.action.bean;

public class NpaZipCodeBean {
  private String KT_PZONE;
  
  private String KT_CNTY;
  
  private String KT_TOWN;
  
  private String KT_DID;
  
  public String getKT_PZONE() {
    return this.KT_PZONE;
  }
  
  public void setKT_PZONE(String kT_PZONE) {
    this.KT_PZONE = kT_PZONE;
  }
  
  public String getKT_CNTY() {
    return this.KT_CNTY;
  }
  
  public void setKT_CNTY(String kT_CNTY) {
    this.KT_CNTY = kT_CNTY;
  }
  
  public String getKT_TOWN() {
    return this.KT_TOWN;
  }
  
  public void setKT_TOWN(String kT_TOWN) {
    this.KT_TOWN = kT_TOWN;
  }
  
  public String getKT_DID() {
    return this.KT_DID;
  }
  
  public void setKT_DID(String kT_DID) {
    this.KT_DID = kT_DID;
  }
}


/* Location:              D:\Qian\IL 居留系統\20200529取得最新程式\IL2\WEB-INF\classes\!\tw\gov\npa\il\action\bean\NpaZipCodeBean.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */