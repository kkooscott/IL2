package tw.gov.npa.il.action;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.log4j.Logger;

public class IL10A002M extends ActionSupport {
  private static final Logger logger = Logger.getLogger(IL10A002M.class);
  
  public String toIL10A002M() throws Exception {
    return "success";
  }
  
  public String doDelete() throws Exception {
    return "success";
  }
  
  public String doUpdate() throws Exception {
    return "success";
  }
  
  public String doAdd() throws Exception {
    return "success";
  }
  
  public String toAdd() throws Exception {
    return "success";
  }
}


/* Location:              D:\Qian\IL 居留系統\20200529取得最新程式\IL2\WEB-INF\classes\!\tw\gov\npa\il\action\IL10A002M.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */