package tw.gov.npa.il.action.bean;

import java.sql.Timestamp;

public class IL03A01Q07Bean {
  private int id;
  
  private Timestamp ilPtrldt;
  
  private String ilPtrlst;
  
  private String ilPtrlmrk;
  
  private String ilUnm;
  
  public int getId() {
    return this.id;
  }
  
  public void setId(int id) {
    this.id = id;
  }
  
  public Timestamp getIlPtrldt() {
    return this.ilPtrldt;
  }
  
  public void setIlPtrldt(Timestamp ilPtrldt) {
    this.ilPtrldt = ilPtrldt;
  }
  
  public String getIlPtrlst() {
    return this.ilPtrlst;
  }
  
  public void setIlPtrlst(String ilPtrlst) {
    this.ilPtrlst = ilPtrlst;
  }
  
  public String getIlPtrlmrk() {
    return this.ilPtrlmrk;
  }
  
  public void setIlPtrlmrk(String ilPtrlmrk) {
    this.ilPtrlmrk = ilPtrlmrk;
  }
  
  public String getIlUnm() {
    return this.ilUnm;
  }
  
  public void setIlUnm(String ilUnm) {
    this.ilUnm = ilUnm;
  }
}


/* Location:              D:\Qian\IL 居留系統\20200529取得最新程式\IL2\WEB-INF\classes\!\tw\gov\npa\il\action\bean\IL03A01Q07Bean.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */