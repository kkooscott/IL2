package tw.gov.npa.il.dao;

import org.hibernate.Session;

public interface IBaseHibernateDAO {
  Session getSession();
}


/* Location:              D:\Qian\IL 居留系統\20200529取得最新程式\IL2\WEB-INF\classes\!\tw\gov\npa\il\dao\IBaseHibernateDAO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */