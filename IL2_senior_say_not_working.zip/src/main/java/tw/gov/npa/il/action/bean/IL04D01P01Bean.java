package tw.gov.npa.il.action.bean;

import java.sql.Timestamp;

public class IL04D01P01Bean {
  private String id;
  
  private String ilUid;
  
  private String ilRptid;
  
  private Timestamp ilSnddt;
  
  private String ilRptnm;
  
  private String ilRptfn;
  
  private String ilStatus;
  
  public String getId() {
    return this.id;
  }
  
  public void setId(String id) {
    this.id = id;
  }
  
  public String getIlUid() {
    return this.ilUid;
  }
  
  public void setIlUid(String ilUid) {
    this.ilUid = ilUid;
  }
  
  public String getIlRptid() {
    return this.ilRptid;
  }
  
  public void setIlRptid(String ilRptid) {
    this.ilRptid = ilRptid;
  }
  
  public Timestamp getIlSnddt() {
    return this.ilSnddt;
  }
  
  public void setIlSnddt(Timestamp ilSnddt) {
    this.ilSnddt = ilSnddt;
  }
  
  public String getIlRptnm() {
    return this.ilRptnm;
  }
  
  public void setIlRptnm(String ilRptnm) {
    this.ilRptnm = ilRptnm;
  }
  
  public String getIlRptfn() {
    return this.ilRptfn;
  }
  
  public void setIlRptfn(String ilRptfn) {
    this.ilRptfn = ilRptfn;
  }
  
  public String getIlStatus() {
    return this.ilStatus;
  }
  
  public void setIlStatus(String ilStatus) {
    this.ilStatus = ilStatus;
  }
}


/* Location:              D:\Qian\IL 居留系統\20200529取得最新程式\IL2\WEB-INF\classes\!\tw\gov\npa\il\action\bean\IL04D01P01Bean.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */